/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author sadali
 */
public class UpdateRecord {
    Statement stmt;
    
    public void Updatenewstudent(String studentID, String name, String fatherName,String courseName, String branchName){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("Update newstudent SET ,Name='"+name+"',Father_Name='"+fatherName+"',courseName='"+courseName+"',branchName='"+branchName+"',' WHERE studentID='"+studentID+"' ");
        }
        catch(SQLException e){
        } 
    
    }
    
    public void Updatebook(String bookID, String name, String publisher ,String price, String publisherYear){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("Update book SET ,Name='"+name+"',Publisher='"+publisher+"',Price='"+price+"',publisherYear='"+publisherYear+"',' WHERE bookID='"+bookID+"' ");
        }
        catch(SQLException e){
        } 
    
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
