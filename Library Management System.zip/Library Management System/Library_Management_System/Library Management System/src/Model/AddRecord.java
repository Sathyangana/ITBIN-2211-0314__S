/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author sadali
 */
public class AddRecord {
    Statement stmt;
    
    public void Add(String studentID, String name, String fatherName,String courseName, String branchName){
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("INSERT INTO newstudent VALUES('"+studentID+"', '"+name+"', '"+fatherName+"', '"+courseName+"', '"+branchName+"')");
        }
        catch (Exception e){
            e.printStackTrace();
        }  
        
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
