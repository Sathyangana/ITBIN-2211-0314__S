/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author sadali
 */
public class DBSearch {
    Statement stmt;
    ResultSet rs;
    
    public ResultSet searchLoging(String ID){
    try{
        stmt = DBConnection.getStatementConnection();
        String User_Name = ID;//Execute Quary
        rs = stmt.executeQuery("SELECT * FROM sign_up WHERE User_Name='"+User_Name+"'");
    }
    catch (Exception e){
        e.printStackTrace();
    }return rs;
}
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
