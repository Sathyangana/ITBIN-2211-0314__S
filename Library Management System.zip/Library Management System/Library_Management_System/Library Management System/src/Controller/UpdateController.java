/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author sadali
 */
public class UpdateController {
    public static void Updatenewstudent(String studentID, String name, String fatherName,String courseName, String branchName){
        
       // int Tele = Integer.parseInt(Contact);
        new Model.UpdateRecord().Updatenewstudent(studentID, name,  fatherName, courseName,  branchName);
        JOptionPane.showMessageDialog(null, "Details has been updated", "Successful",JOptionPane.INFORMATION_MESSAGE);
          
    }public static void Updatebook(String bookID, String name, String publisher ,String price, String publisherYear){
        
       // int Tele = Integer.parseInt(Contact);
        new Model.UpdateRecord().Updatebook(bookID, name,  publisher, price,  publisherYear);
        JOptionPane.showMessageDialog(null, "Details has been updated", "Successful",JOptionPane.INFORMATION_MESSAGE);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
