-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2024 at 08:07 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bookID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `publisherYear` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bookID`, `name`, `publisher`, `price`, `publisherYear`) VALUES
(100, 'Erath', 'Delisha', '1000', 2015),
(101, 'Alibaba', 'Alif kan', '550', 2019),
(102, 'Casper', 'Ganster', '500', 2000),
(103, 'End of the Earth', 'Sathya', '1000', 2016),
(105, 'Orayan ', 'Oriza', '580', 2016),
(106, 'Gan Leader', 'Yashin', '950', 2014);

-- --------------------------------------------------------

--
-- Table structure for table `issues_book`
--

CREATE TABLE `issues_book` (
  `book_id` int(11) NOT NULL,
  `student_id` int(225) NOT NULL,
  `issue_date` varchar(25) NOT NULL,
  `due_date` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issues_book`
--

INSERT INTO `issues_book` (`book_id`, `student_id`, `issue_date`, `due_date`) VALUES
(105, 4, '2024-06-04', '2024-08-08'),
(103, 1, '2024-05-15', '2024-06-30'),
(102, 3, '2024-03-25', '2024-05-13'),
(101, 7, '2024-07-20', '2024-08-31');

-- --------------------------------------------------------

--
-- Table structure for table `newstudent`
--

CREATE TABLE `newstudent` (
  `studentID` int(10) NOT NULL,
  `name` varchar(225) NOT NULL,
  `fatherName` varchar(225) NOT NULL,
  `courseName` varchar(225) NOT NULL,
  `branchName` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newstudent`
--

INSERT INTO `newstudent` (`studentID`, `name`, `fatherName`, `courseName`, `branchName`) VALUES
(1, 'Sakil', 'Serasingha', 'E.Tech', 'MACANIC'),
(2, 'Thiwnka', 'Hemantha', 'B.Tech', 'CIVIL'),
(3, 'Samadi', 'Waththegedara', 'E.Tech', 'CIVIL'),
(5, 'Pramuditha', 'Stony', 'B.Tech', 'MACANIC'),
(6, 'Pawan', 'Anteny', 'E.Tech', 'IT'),
(7, 'Neluminda', 'Koswaththa', 'B.Tech', 'CSE'),
(8, 'Nelum', 'Franando', 'B.Tech', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `return_book`
--

CREATE TABLE `return_book` (
  `book_id` int(200) NOT NULL,
  `student_id` int(200) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `return_book`
--

INSERT INTO `return_book` (`book_id`, `student_id`, `issue_date`, `due_date`) VALUES
(105, 4, '2024-06-04', '2024-07-25'),
(103, 1, '2024-05-15', '2024-06-05'),
(102, 3, '2024-03-25', '2024-05-10'),
(101, 7, '2024-07-20', '2024-08-31');

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `User_Name` varchar(200) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`User_Name`, `Password`) VALUES
('admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bookID`);

--
-- Indexes for table `newstudent`
--
ALTER TABLE `newstudent`
  ADD PRIMARY KEY (`studentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
